var indexSectionsWithContent =
{
  0: "abcdefhiklmopqrstuw",
  1: "m",
  2: "m",
  3: "m",
  4: "acfhiklmostw",
  5: "m",
  6: "t",
  7: "t",
  8: "bdefhlmpqru"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Определения типов",
  6: "Перечисления",
  7: "Элементы перечислений",
  8: "Макросы"
};

