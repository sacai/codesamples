var searchData=
[
  ['pgdn_5fdig',['PGDN_DIG',['../minicurs_8h.html#a5c560e97b151792390bfee43037072e9',1,'minicurs.h']]],
  ['pgdn_5fsym',['PGDN_SYM',['../minicurs_8h.html#a1645615183144b3cfc0b11b2ae67d9fc',1,'minicurs.h']]],
  ['pgup_5fdig',['PGUP_DIG',['../minicurs_8h.html#ad1294729ea2b9635b8dee7f71a3083f3',1,'minicurs.h']]],
  ['pgup_5fsym',['PGUP_SYM',['../minicurs_8h.html#a9e1670aa9b77aa5263251a6019f5c89b',1,'minicurs.h']]]
];
