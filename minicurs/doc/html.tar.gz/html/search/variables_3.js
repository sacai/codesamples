var searchData=
[
  ['header',['header',['../structmcurses__menu__t.html#a0ffb445a2fec4b4113ad73f3c78a5373',1,'mcurses_menu_t']]]
];
