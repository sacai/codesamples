var searchData=
[
  ['minicurs_2eh',['minicurs.h',['../minicurs_8h.html',1,'']]]
];
