var searchData=
[
  ['oldt',['oldt',['../structminicurses__t.html#aada111e71db64f75db6328e41fe06ae9',1,'minicurses_t']]]
];
