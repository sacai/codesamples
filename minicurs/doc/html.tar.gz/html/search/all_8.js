var searchData=
[
  ['key_5ffunc',['key_func',['../structmcurses__menu__t.html#a030caa067a0a49855418663dd594746e',1,'mcurses_menu_t']]]
];
