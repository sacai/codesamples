var searchData=
[
  ['up_5fsym',['UP_SYM',['../minicurs_8h.html#a01f1d47c9566e8051941847d341d5725',1,'minicurs.h']]]
];
