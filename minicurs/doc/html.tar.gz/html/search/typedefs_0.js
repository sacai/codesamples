var searchData=
[
  ['mcurses_5fkey_5fhandler_5ft',['mcurses_key_handler_t',['../minicurs_8h.html#aa74ec0fe0943d46245181c94c905672d',1,'minicurs.h']]],
  ['mcurses_5fmenu_5fitem_5fhandler_5ft',['mcurses_menu_item_handler_t',['../minicurs_8h.html#ae72668e7853b375735b4c0e90ae7e0e0',1,'minicurs.h']]]
];
