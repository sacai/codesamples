var searchData=
[
  ['ta_5fblink',['ta_blink',['../minicurs_8h.html#a81ec85632804d16201209ee4fe10354ea6078bce36de5da7fb434507e8f99577e',1,'minicurs.h']]],
  ['ta_5fbold',['ta_bold',['../minicurs_8h.html#a81ec85632804d16201209ee4fe10354eafe29272fc81b23b4ee4118f60591c971',1,'minicurs.h']]],
  ['ta_5finv',['ta_inv',['../minicurs_8h.html#a81ec85632804d16201209ee4fe10354eadbd25440196a17da4eeb3a59e7733a34',1,'minicurs.h']]],
  ['ta_5fnormal',['ta_normal',['../minicurs_8h.html#a81ec85632804d16201209ee4fe10354ea1a248069ce86af4bf29d9cbedaff49d2',1,'minicurs.h']]],
  ['ta_5funderline',['ta_underline',['../minicurs_8h.html#a81ec85632804d16201209ee4fe10354eae5d282a83c9d024e0e7b799dff968c79',1,'minicurs.h']]],
  ['term_5ftype',['term_type',['../structminicurses__t.html#a5b9d5cc8614fc480a3f3749a862da7c5',1,'minicurses_t']]],
  ['text',['text',['../structmcurses__menu__item__t.html#a1a3ffcd413251224f01456da2e0e85f0',1,'mcurses_menu_item_t']]],
  ['txt_5fattr',['txt_attr',['../minicurs_8h.html#a81ec85632804d16201209ee4fe10354e',1,'minicurs.h']]]
];
