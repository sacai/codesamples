var searchData=
[
  ['dn_5fsym',['DN_SYM',['../minicurs_8h.html#a8d4ec52bd297d3f8ee9344dc5612d951',1,'minicurs.h']]]
];
