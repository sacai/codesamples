var searchData=
[
  ['term_5ftype',['term_type',['../structminicurses__t.html#a5b9d5cc8614fc480a3f3749a862da7c5',1,'minicurses_t']]],
  ['text',['text',['../structmcurses__menu__item__t.html#a1a3ffcd413251224f01456da2e0e85f0',1,'mcurses_menu_item_t']]]
];
