var searchData=
[
  ['fin_5fsym',['FIN_SYM',['../minicurs_8h.html#a4e1f88afa0488e410308d31ca8333c8b',1,'minicurs.h']]]
];
