var searchData=
[
  ['mcurses',['mcurses',['../structmcurses__menu__t.html#a0f8a7672dfde07122d570aa5e39bb09a',1,'mcurses_menu_t']]]
];
