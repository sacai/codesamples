var searchData=
[
  ['fin_5fsym',['FIN_SYM',['../minicurs_8h.html#a4e1f88afa0488e410308d31ca8333c8b',1,'minicurs.h']]],
  ['float_5fdata',['float_data',['../structmcurses__menu__item__t.html#af6efedff76e6e8ded1cc9dc53aafbc95',1,'mcurses_menu_item_t']]]
];
