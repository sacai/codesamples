var searchData=
[
  ['txt_5fattr',['txt_attr',['../minicurs_8h.html#a81ec85632804d16201209ee4fe10354e',1,'minicurs.h']]]
];
