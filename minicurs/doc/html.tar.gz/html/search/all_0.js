var searchData=
[
  ['allocated',['allocated',['../structmcurses__menu__t.html#a5caaff81de0a235c21421a362d2314fb',1,'mcurses_menu_t']]]
];
