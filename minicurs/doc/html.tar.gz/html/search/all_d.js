var searchData=
[
  ['quit_5fsym',['qUIT_SYM',['../minicurs_8h.html#a8ef305b304360ed0be036f5484f3dfe3',1,'qUIT_SYM():&#160;minicurs.h'],['../minicurs_8h.html#ac148f77d2e2f7118cd875e57884b2e50',1,'QUIT_SYM():&#160;minicurs.h']]]
];
